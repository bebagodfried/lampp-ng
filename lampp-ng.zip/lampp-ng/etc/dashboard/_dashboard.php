        <div class="grid p-1 px-6">
          <div class="grid-row g-2">

            <div class="col-6 p-2 rounded shadow-md">

              <div class="flex justify-between">
                <h5 class="currentColor m-0">Software</h5>
                <form action="" method="get" class="p-1">
                  <div class="flex-row justify-content-end rounded bg-grey-300">
                    <input type="search" name="" id="" class="bg-none no-border m-0" placeholder="Search a project ...">
                    <button type="submit" class="absolute bg-none "><i class="fa-solid fa-search"></i></button>
                  </div>
                </form>
              </div>

              <div class="grid">
                <div class="grid grid-cols-3 g-1 p-1">

                  <button class="p-1 bg-none bordered" onclick="window.open('file://<?= $_SERVER['DOCUMENT_ROOT'] ?>', '_blank')">
                    <i class="fa-solid fa-folder-open"></i>
                    <span>File manager</span>
                  </button>

                  <button class="p-1 bg-none bordered" onclick="goto('/phpmyadmin')">
                    <i class="fa-solid fa-database"></i>
                    <span>phpMyAdmin</span>
                  </button>

                  <button class="p-1 bg-none bordered" onclick="goto('info.php', 'blank')">
                    <i class="fa-solid fa-server"></i>
                    <span>Server Infos</span>
                  </button>
                </div>
                <div class="">

                </div>
              </div>
              
              <div class="flex">
                <a href="controls.php?sysinfo=os" class="underline">System Information</a>
              </div>

              <div id="test"></div>
            </div>

            <div class="col-6 p-2 rounded shadow-md">
              <h5 class="currentColor">Usage</h5>

              <!-- CPU -->
              <div class="flex solid border-0 border-b-1 py-1">
                <span class="flex-1">CPU</span>
                <div class="inline-flex g-2 flex-2">
                  <progress class="no-border rounded-0 flex-2" id="cpu" height="5" max="100" value="<?= $used_cpu ?>"></progress> <span class="small inline-flex flex-1 justify-end" width="100"><?= $used_cpu ?>% of <?= _cpu('proc') ?>CPUs</span>
                </div>
              </div>

              <!-- RAM -->
              <div class="flex solid border-0 border-b-1 py-1">
                <span class="flex-1">RAM</span>
                <div class="inline-flex g-2 flex-2">
                  <progress class="no-border rounded-0 flex-2" id="ram" height="5" max="<?= (double)_ram('size') ?>" value="<?= (double)_ram('used') ?>"></progress> <span class="small inline-flex flex-1 justify-end" width="100"><?= _ram('used') ?>/<?= _ram('size') ?>MiB</span>
                </div>
              </div>

              <!-- DISK -->
              <div class="flex solid border-0 border-b-1 py-1">
                <span class="flex-1">Disk</span>
                <div class="inline-flex g-2 flex-2">
                  <progress class="no-border rounded-0 flex-2" height="5" max="<?= (double)_disk('size') ?>" value="<?= (double)_disk('used') ?>"></progress> <span class="small inline-flex flex-1 justify-end" width="100"><?= _disk('used') ?>/<?= _disk('size') ?></span>
                </div>
              </div>

              <!-- DATABASE -->
              <div class="flex solid border-0 border-b-1 py-1">
                <span class="flex-1">Database</span>
                <div class="inline-flex g-2 flex-2">
                  <progress class="no-border rounded-0 flex-2" height="5" max="100" value="<?= $db_count ?>"></progress> <span class="small inline-flex flex-1 justify-end" width="100"><?= $db_count ?>/100+</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <hr class="divider w-90 opacity-10">

        <div class="px-6 py-1">
          <div class="px-2">
            <h5 class="currentColor m-0 \ flex g-1">Your projects <span class="inline-flex medium size-24 rounded-full bg-light text-dark fw-900"><?= count_project() ?></span></h5>
            <ul class="flex g-2 px-1">
              <?php ls_project() ?>
            </ul>
          </div>
        </div>

        <script>

        </script>

        <!-- ------------------------- -->

