<?php
  error_reporting(E_ALL);
  ini_set('display_errors', 1);
  include "includes/dbconnect.php";

  // Get root directory
  $root = $_SERVER['DOCUMENT_ROOT'];

  // Database
  // count all db except predefined database
  function db_count() {
    // get the database
    global $db_connection;
    
    $db = mysqli_query($db_connection,"SELECT COUNT(*) AS dbase FROM information_schema.SCHEMATA WHERE schema_name NOT IN('mysql','information_schema','phpmyadmin','performance_schema', 'sys')");
    
    $db_count = mysqli_fetch_assoc($db);
    $db_count = $db_count['dbase'];

    return $db_count;
  }

  $db_count = db_count();

  // System informations
  // CPU
  function _cpu($option) {
    $cpu_proc = shell_exec("lscpu | awk 'NR==5{print $2}'");
    $cpu_idle = shell_exec("top -b -n 1|grep '%Cpu' |awk '{print $8}'");
    $cpu_info = shell_exec("lscpu | awk 'NR==8'");

    $cpu_used= ((( 100 - (double)$cpu_idle)/100) * 100);

    switch ($option) {
      case 'proc':
        return $cpu_proc;

      case 'used':
        return $cpu_used;
      
      default:
        return $cpu_info;
    }
  }

  $used_cpu = _cpu('used');

  // Memory
  function _ram($option) {
    $ram_size = shell_exec("free -m | awk 'NR==2{print $2}'");
    $ram_used = shell_exec("free -m | awk 'NR==2{print $3}'");

    $ram_info = number_format($ram_used/1024, 2) . ' / ' . number_format($ram_size/1024, 2) . 'GiB (' . number_format($ram_used  / $ram_size * 100) . '%)';

    switch ($option) {
      case 'size':
        return $ram_size;

      case 'used':
        return $ram_used;
      
      default:
        return $ram_info;
    }
  }

  // Disk
  function _disk($option) {
    $disk_size = shell_exec("df -h / | awk 'NR==2{print $2}'");
    $disk_used = shell_exec("df -h / | awk 'NR==2{print $3}'");
    $disk_info = (float)$disk_used . ' / ' . (float)$disk_size . 'GiB (' . number_format((float)$disk_used  / (float)$disk_size * 100) . '%)';

    switch ($option) {
      case 'size':
        return $disk_size;

      case 'used':
        return $disk_used;
      
      default:
        return $disk_info;
    }
  }

  // Hostname
  $hostname = php_uname('n');

  // Request an information from server
  $sysinfo = @$_GET['sysinfo']; // variable data request
  $uptime  = shell_exec('uptime'); // Running time

  // User information
  $user = shell_exec('echo $USER');
  $user = trim($user);

  // Project
  // list your projects
  function ls_project($list_all = false) {
    global $root;
    $dir = $root;

    if ( isset($_GET['dir']) ) {
      $get = $_GET['dir'] . '/';

      $dir = $_GET['dir'] . '/';
      $dir = $root . '/' . $dir;
    }
    // Check if the directory exists and is readable
    if ( is_dir( $dir ) && is_readable( $dir ) ) {

      // Scan files and directories
      $files = scandir($dir);
      
      // elements display style
      $style = "p-1 hover:underline hover:ease-in";

      foreach ($files as $file) {
        if ($file !== '.' && $file !== '..' && $file !== 'index.php') {
          $filePath = $root . '/' . $file;

          if ($list_all) {
            // display all including dot files 
            echo
            '<li class="">
              <a href="../' . @$get . $file . '" target="_blank" class="monospace ' .  $style . '"> ' . $file . '</a>
            </li>';
          } else {
            // no dot files displayed
            if ($file[0] !== '.') {
              echo
              '<li class="">
                <a href="../' . @$get . $file . '" target="_blank" class="monospace ' .  $style . '"> ' . $file . '</a>
              </li>';
            }
          }
        }
      }
    } else {
      echo "<li>Directory <i class='text-red monospace'>`$root`</i> not found or not readable!</li>";
    }
  }

  // count your projects
  function count_project($list_all = false) {
    global $root;
    $dir = $root;
    $i = 0;

    if ( isset($_GET['dir']) ) {
      $get = $_GET['dir'] . '/';

      $dir = $_GET['dir'] . '/';
      $dir = $root . '/' . $dir;
    }
    // Check if the directory exists and is readable
    if ( is_dir( $dir ) && is_readable( $dir ) ) {

      // Scan files and directories
      $files = scandir($dir);
      
      // elements display style
      $style = "p-1 hover:underline hover:ease-in";

      foreach ($files as $file) {
        if ($file !== '.' && $file !== '..' && $file !== 'index.php') {
          $filePath = $root . '/' . $file;

          if ($list_all) {
            // display all including dot files 
            $i++;
          } else {
            // no dot files displayed
            if ($file[0] !== '.') {
              $i++;
            }
          }
        }
      }

      return $i;
    } else {
      return 0;
    }
  }

  // Host
  // Host informations
  $host = $_SERVER['HTTP_HOST'];

  if ($_SERVER['REQUEST_SCHEME'] == 'http') {
    $uri = 'http://';
  } else {
    $uri = 'https://';
  }

  $url = $uri . $host . $_SERVER['REQUEST_URI'];
  $request = $_SERVER['REQUEST_URI'];
  // echo $request;

  // Get your current page request
  $page = $_SERVER['REQUEST_URI'];


  // Get Apache server status
  $httpd_status = shell_exec("sudo systemctl is-active httpd");

  // Get database server status
  $mariadb_status = shell_exec("sudo systemctl is-active mariadb");

  // ==================================================================
  function is_home() {
    global $page;

    if ($page == '/dashboard/' || $page == '/dashboard/index.php' || isset( $_GET['dir'] ) ) {
      return true;
    }
  }

  function is_panel() {
    global $page;

    if ( $page == '/dashboard/controls.php' || $sysinfo ) {
      return true;
    }
  }
  
  function error($err) {
    return 
    "<span class=\"monospqce fg-danger\">$err</span>";
  }
?>