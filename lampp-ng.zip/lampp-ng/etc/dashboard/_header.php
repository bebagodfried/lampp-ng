<?php
  $enabled = "p-1 solid border-0 border-b-3 hover:ease-in border-primary bg-black";
  $disable = "p-1 solid border-0 border-b-3 hover:ease-in border-grey hover:bg-grey";

  $page = $_SERVER['REQUEST_URI'];
?>
      
      <div class="solid border-0 border-r-1 border-grey-500 sticky top-0">
        <header class="bg-none p-2 px-6">
          <div class="flex justify-between w-100">
            <div class="font-14 inline-flex g-1">
              <!--  -->
              <img src="includes/pixmaps/logo/fedora.png" alt="fedora-logo" class="size-48">
              
              <div class="">
                <span class="block fw-900"><?= $user ?>@</span>
                <span class="fw-500"><a href="<?= $uri . $host . '/dashboard' ?>" class="currentColor hover:underline"><?= $host ?></a></span>
              </div>
            </div>
            <button class="bg-grey-500 hover:bg-grey-300 hover:ease-in p-0 size-32 rounded-full" onclick="goto(location.href); display('#loader', 'flex')">
              <i class="fa-solid fa-arrow-rotate-right"></i>
            </button>
          </div>
        </header>
        <!--  -->
        <ul class="flex p-1 px-6">
          <div class="p-1 fixed bottom-5 right-5 z-8 <?php if ( is_home() ) { echo null; } else { echo 'hidden'; } ?>">
            <button class="bordered bg-none rounded w-full" onclick="goto('install.php'); display('#loader', 'flex')"><i class="fa-regular fa-plus"></i> New project</button>
          </div>
          
          <li><a href="/dashboard" class="<?php if (  is_home() ) { echo $enabled; } else { echo $disable; } ?>" onclick="display('#loader', 'flex')"><i class="fa-solid fa-dashboard"></i> Dashboard</a></li>
          <li><a href="controls.php" class="<?php if ( is_panel() ) { echo $enabled; } else { echo $disable; } ?>" onclick="display('#loader', 'flex')"><i class="fa-solid fa-gears"></i> Configurations</a></li>
        </ul>
      </div>

      <!--  -->




        <header class="bg-black medium p-2" hidden>
          <div class="flex justify-end w-100">
            <h5 class="center flex-1 font-comfortaa fw-900 m-0"><?= php_uname('n'); ?> web server</h5>
            <ul class="relative"> 
              <button class="bg-none g-1 " onclick="display('#menu')">
                <i class="fa-solid fa-bars"></i>
              </button>

              <div id="menu" class="absolute z-9 right-0 w-full bg-dark shadow-md width-200 p-1 rounded hidden">
                <table class="w-100">

                  <tr class="mb-1">
                    <td class="px-1 max-w-50">apache </td>
                    <td class="px-1 code <?= $httpd = ($httpd_status == 'active' ) ? "fg-success" : "fg-danger" ; ?>">:<?= $httpd_status ?></td>
                  </tr>

                  <tr class="mb-1">
                    <td class="px-1 max-w-50">mariadb</td>
                    <td class="px-1 code <?= $mariadb = ($mariadb_status == 'active' ) ? "fg-success" : "fg-danger" ; ?>">:<?= $mariadb_status ?></td>
                  </tr>

                </table>
              <div>
            </ul>
            
          </div>
        </header>