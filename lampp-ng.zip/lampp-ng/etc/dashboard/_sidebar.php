<?php
  $enabled = "p-1 solid border-0 border-b-3 hover:ease-in border-primary bg-black";
  $disable = "p-1 solid border-0 border-b-3 hover:ease-in border-dark hover:bg-grey";

  $nav = $_SERVER['REQUEST_URI'];
?>
      
      <div class="col-2 solid border-0 border-r-1 border-grey-500" hidden>
        <header class="bg-none medium p-2">
          <div class="flex justify-between w-100">
            <div class="font-14">
              <span class="block">@<?= $user ?></span>
              <span class="fw-500"><a href="<?= $uri . $host . '/dashboard' ?>" class="currentColor hover:underline"><?= $host ?></a></span>
            </div>
            <button class="bg-grey-500 hover:bg-grey-300 hover:ease-in p-0 size-32 rounded-full" onclick="goto(location.href); display('#loader', 'flex')">
              <i class="fa-solid fa-arrow-rotate-right"></i>
            </button>
          </div>
        </header>
        <!--  -->
        <ul class="py-1">
          <div class="p-1">
            <button class="bordered bg-none rounded w-full" onclick="goto('install.php'); display('#loader', 'flex')">New project</button>
          </div>
          
          <li><a href="/dashboard" class="<?php if ($nav == '/dashboard/' || $nav == '/dashboard/index.php') { echo $enabled; } else { echo $disable; } ?>" onclick="display('#loader', 'flex')">Dashboard</a></li>
          <li><a href="controls.php" class="<?php if ($nav == '/dashboard/controls.php' || $sysinfo) { echo $enabled; } else { echo $disable; } ?>" onclick="display('#loader', 'flex')"><i class="fa-solid fa-slider"></i>Configurations</a></li>
        </ul>
      </div>

      <!--  -->