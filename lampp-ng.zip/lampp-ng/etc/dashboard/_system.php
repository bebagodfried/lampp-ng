<?php
// Operating System Information
$osName = php_uname('s'); // Get the operating system name
$osVersion = php_uname('r'); // Get the operating system version
$osArchitecture = php_uname('m'); // Get the operating system architecture

$kernelVersion = php_uname('v'); // Get the kernel version


function div($data, $properties = "") {
  echo
  "<div $properties>
    $data
  </div>";
  return null;
}

?>
<h5></h5>
<table class="mx-auto my-6">
  <tr class="bg-grey p-2 text-left">
    <th class="p-2">Property</th>
    <th class="p-2">Value</th>
  </tr>

  <tr>
    <td class="bordered p-2">Operating System</td>
    <td class="bordered p-2"><?= $osName ?></td>
  </tr>

  <tr>
    <td class="bordered p-2">Version</td>
    <td class="bordered p-2"><?= $osVersion ?></td>
  </tr>

  <tr>
    <td class="bordered p-2">Architecture</td>
    <td class="bordered p-2"><?= $osArchitecture ?></td>
  </tr>

  <tr>
    <td class="bordered p-2">CPU</td>
    <td class="bordered p-2"><?= _cpu('infos') ?></td>
  </tr>

  <tr>
    <td class="bordered p-2">RAM</td>
    <td class="bordered p-2"><?= _ram('infos') ?></td>
  </tr>

  <tr>
    <td class="bordered p-2">Disk</td>
    <td class="bordered p-2"><?= _disk('infos') ?></td>
  </tr>

  <tr>
    <td class="spacer"></td>
  </tr>

<?php
  if ($sysinfo != 'os') {
    foreach ($_SERVER as $key => $value) {
      echo
      "<tr>
        <td class=\"bordered p-2\">$key</td>
        <td class=\"bordered p-2\">$value</td>
      </tr>";
    } 
  }
?>

</table>