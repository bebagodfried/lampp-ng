<?Php
  $host = 'localhost';
  $user = 'root';
  $pass = 'root';

  $db_connection = mysqli_connect($host,$user,$pass);
 ?>