<?php
// 
  $nav = [
    'Dashboard'   => '/dashboard/',
    'System info' => '/dashboard/controls.php',
    'Configs'     => '/dashboard',
    "\"PHP \".PHP_VERSION"     => '/dashboard',
  ];

  foreach ($nav as $key => $value) {
    global $request;
    if ( $request == $value ) {
      $title = $key;
      break;
    }
  }