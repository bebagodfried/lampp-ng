<?php
  include '_functions.php';
  include 'includes/head.php';
?>

<body class="bg-dark fg-light font-15">
  <!-- loader -->
  <div id="loader" class="absolute fit-screen z-9 bg-black-alpha-80 ease-in flex justify-center">
    <img src="includes/loader/spin.gif" alt="loader" class="size-96">
  </div>

  <main class="grid fit-screen overflow-scroll">
    <div class="grid-row items-stretch h-100">
      <section class="stretch">

        <?php include "_header.php" ?>

        <!-- content -->
        <?php include "_dashboard.php" ?>
        <?php //include "info.php" ?>
      </section>
    </div>
  </main>
  
  <!-- footer -->
  <footer class="absolute">

  </footer>

  <?php include 'script.php' ?>

</body>
</html>