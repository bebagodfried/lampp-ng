<?php
  // include '_functions.php';
  include 'includes/head.php';
  ?>

<body class="bg-dark fg-light font-15">
  <!-- loader -->
  <div id="loader" class="absolute fit-screen z-9 bg-black-alpha-80 ease-in flex justify-center">
    <img src="includes/loader/spin.gif" alt="loader" class="size-96">
  </div>

  <main class="grid fit-screen overflow-scroll">
    <div class="grid-row items-stretch h-100">
      <!-- sidebar -->
      <?php include "_sidebar.php" ?>

      <section class="col-10 stretch">

        <?php include "_header.php" ?>

        <!-- content -->
        <?php include "info.php" ?>
      </section>
    </div>
  </main>
  
  <!-- footer -->
  <footer class="absolute">

  </footer>

  <?php include 'script.php' ?>

</body>
</html>
<style>
  ::-webkit-scrollbar {
    background: #333;
    width: 5px;
  }

  ::-webkit-scrollbar-thumb {
    background: #03A9F4;
    border-width: 1px;
    border-style: solid;
    border-color: #03A9F4;
    border-radius: 0.75rem;
    overflow: hidden;
  }

  body {
    background-color: #333;
    background-image: url(includes/theme/img/000-default.svg);
  }

  a:hover {
    cursor: default;
  }

  a:link {
    background: none;
    cursor: pointer;
  }

  h1, h2 {
    color: #fff;
    font-weight: 600;
    margin: 0
  }

  h1 {
    font-size: 150%
  }

  h2 {
    font-size: 125%
  }

  table {
    background-color: #ddd;
  }

  td {
    vertical-align: middle;
  }

  .h td {
    display: flex;
      align-items: center;
      flex-direction: row-reverse;
      justify-content: space-between
  }

</style>