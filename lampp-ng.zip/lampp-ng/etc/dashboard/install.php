<?php
  include '_functions.php';
  include 'includes/head.php';

  $request = $_SERVER['REQUEST_METHOD'];

  if ($request == 'POST') {
    $name  = ($_POST['name']) ? $_POST['name'] : NULL;
    $app   = ($_POST['app']) ? $_POST['app'] : NULL;

    if ($name) {
      // 
      $dirname = $root . '/' . $name;

      if (file_exists($dirname)) {
        $install = error( '`<b>' . $name . '</b>` already exist');
      } else {
        // Check permissions
        $perms = fileperms(__DIR__);
        $perms = substr(sprintf('%o', $perms), -3);

        if ($perms == 755) {       
          // Check the installer
          switch ($app) {
            case 'wordpress':
              $install = 'Connecting to wordpress.org...';
              exec("mkdir " . $dirname );
              if (mkdir( $dirname, 0777 )) {
                $exec = '[connected]';
              } else {
                $exec = error('[error]' . $dirname );
              }
              break;
              
            default:
              $install = 'Initializing...';
              exec( "mkdir " . $dirname );
              if ( mkdir( $dirname, 0777 )) {
                $exec = '[ok]';
              } else {
                $exec = error('[error]' . $dirname );
              }
              break;
          }
        } else {
          $install = error("Permission denied");
        }
      }
    } else {
      $error = error('Required `project name`');
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!--/**
      * Powered by: openCSS [Simple responsive HTML, CSS, JS framework]
      * Version: 2.0.0-beta
      * Author: @bebagodfried
      * Copyright: 2023
      * License: CC BY 4.0, MIT, SIL OFL 1.1
      **/-->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Dashboard &rsaquo; Unity-admin v1.0.0</title>
  <base href="<?= $url . '/' ?>">

  <meta name="generator" content="opencss" />
  <meta property="og:title" content="opencss" />
  <meta property="og:locale" content="en_US" />
  <meta property="og:type" content="opencss" />

  <meta name="description" content="OpenCSS is designed to providing developers with top-quality resources for creating exceptional websites and web applications, focus on flexibility. openCSS offer a range of utility classes, mixins, and variables that can be customized and combined to create unique designs.">
  <meta name="keywords" content="opencss, web, websites, applications, flexibility, utility-class, scss, sass, scss-utility, css3, css-framework, frontend, responsive">

  <!-- style -->
  <link rel="stylesheet" href="includes/theme/open.css">
  <link rel="stylesheet" href="includes/theme/background.css">

</head>
<body class="bg-dark-100 fg-light font-15">
  <!-- loader -->
  <div id="loader" class="absolute fit-screen z-9 bg-black-alpha-80 ease-in flex justify-center">
    <img src="includes/loader/spin.gif" alt="loader" class="size-96">
  </div>

  <main class="grid fit-screen overflow-scroll">
    <div class="grid-row items-stretch h-100">
      <!-- sidebar -->
      <?php include "_sidebar.php" ?>

      <section class="stretch">

        <?php include "_header.php" ?>

        <!-- content -->
        <div class="flex-row p-1 px-6 items-stretch">
          <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post" class="solid-border border-0 border-r-1 flex-1 w-50">
            <div class="p-1">
              <h5 class="currentColor">Create project</h5>

              <div class="p-1">
                <table>
                  <tr class="mb-1">
                    <td class="p-1">
                      <label for="app">Software</label>
                    </td>

                    <td>
                      <select name="app" id="app" class="bg-none currentColor bordered p-1 rounded w-100">
                        <option value="default">Default</option>
                        <option value="wordpress">Wordpress</option>
                      </select>
                    </td>
                  </tr>

                  <tr class="spacer" height="10"></tr>

                  <tr class="mb-1">
                    <td class="p-1">
                      <label for="name">Project name</label>
                    </td>

                    <td class="text-black">
                      <input type="text" name="name" id="name" class="currentColor p-1">
                    </td>
                  </tr>
                </table>

                <div class="mt-1 text-right">
                  <button type="submit">Let's go <i class="fa-solid fa-angle-right"></i></button>
                </div>
              </div>
            </div>
          </form>

          <div class="bg-dark-500 m-1 p-1 bordered border-dark flex-1 rounded">
            <code class="">
              [<?= $user . '@' . $host ?>] <br>
              <?php
                if (!@$error) {
                  echo $step_1 = ($request == 'POST') ? '&rsaquo; '. $install : NULL;
                  echo $step_2 = @$exec;
                } else {
                  echo '&rsaquo; '. @$error;
                }
              ?>
            </code>
          </div>
        </div>
      </section>
    </div>
  </main>
  
  <!-- footer -->
  <footer class="absolute">

  </footer>

  <?php include 'script.php' ?>

</body>
</html>