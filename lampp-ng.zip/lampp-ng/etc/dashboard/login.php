<?php
  $os  = exec("uname -s").' ';
  $os .= exec("uname -n");
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!--/**
      * Powered by: openCSS [Simple responsive HTML, CSS, JS framework]
      * Version: 2.0.0-beta
      * Author: @bebagodfried
      * Copyright: 2023
      * License: CC BY 4.0, MIT, SIL OFL 1.1
      **/-->

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Dashboard &lsaquo; login webAdmin v1.0.0</title>

  <meta name="generator" content="opencss" />
  <meta property="og:title" content="opencss" />
  <meta property="og:locale" content="en_US" />
  <meta property="og:type" content="opencss" />

  <meta name="description" content="OpenCSS is designed to providing developers with top-quality resources for creating exceptional websites and web applications, focus on flexibility. openCSS offer a range of utility classes, mixins, and variables that can be customized and combined to create unique designs.">
  <meta name="keywords" content="opencss, web, websites, applications, flexibility, utility-class, scss, sass, scss-utility, css3, css-framework, frontend, responsive">

  <!-- style -->
  <link rel="stylesheet" href="includes/theme/open.css">
  <link rel="stylesheet" href="includes/background.css">

  <!-- @import opencss:helpers -->
  <script src="includes/theme/helpers/dom.js" defer></script>

</head>
<body class="bg-dark overflow-hidden">
  <section class="">
    <div class="flex-row fit-screen items-center py-6 md:row-reverse">
      <div class="flex items-center g-1">
        <img src="includes/img/logo.png" alt="logo" class="size-96"><h1 class="font-66 fw-900 m-0 text-white comfortaa">lampp</h1>
      </div>

      <div class="inline-flex column items-center">
        <form action="#" method="post" class="inline-block bg-white rounded p-6">

          <div class="block mb-2">
            <p class="comfortaa m-0 capitalize"><?= $os ?> <strong>Web Server</strong></p>
          </div>
          
          <div class="mb-2">
            <label for="u_name" class="fw-500 small">Username</label>

            <span class="block bordered border-light rounded">
              <input type="text" id="u_name" name="u_name" autocapitalize="none" autocomplete="off" class="border-0 border-b-1 border-dark px-1 w-full rounded-none">
            </span>
          </div>
          
          <div class="mb-2">
            <label for="u_pass" class="fw-500 small">Password</label>

            <span class="block bordered border-light rounded">
              <input type="password" id="u_pass" name="u_pass" class="border-0 border-b-1 border-dark px-1 w-full rounded-none">
            </span>
          </div>
          
          <div class="mb-2">
            <button type="submit" class="rounded-none bg-blue-300 hover:bg-blue-400">Log in <img src="" alt=""></button>
          </div>

        </form>

        <!--  -->
        <div class="spacer sm:hidden">
          <!-- 50px -->
        </div>
      </div>
    </div>
  </section>

  <!-- footer -->
  <footer class="absolute">
    
  </footer>
</body>
</html>