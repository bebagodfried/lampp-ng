<!-- // @import opencss: helpers -->
<script src="includes/theme/helpers/dom.js"></script>

<script>
  // loader
  document.body.onload = (() => {
    hide('#loader')
  })

  // Monitoring
  // 
  if (select_id('cpu')) {
    cpu = select_id('cpu');
    
    setTimeout(() => {
      cpu.value = "<?= $used_cpu ?>";
    }, 100);
  }
  
  // 
  window.body = addEventListener('contextmenu', (e) => {
    e.preventDefault();
  })
</script>